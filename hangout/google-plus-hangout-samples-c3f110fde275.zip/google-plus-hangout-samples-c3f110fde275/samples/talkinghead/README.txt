== Hangout Apps Sample - Talking Head ==

== What's Included ==
Herein you will find these files which compose the sample

 - ggs/talkinghead.js   - The JavaScript file which provides most of the 
                          functionality for this hangouts app
 - ggs/talkinghead.xml  - The XML container which describes the app and 
                          provides the initial state
 - static/talkinghead/* - Static files including CSS and images

== Getting Help == 
If you somehow got here without finding the documentation, check out
http://developer.google.com/+/hangouts/

If you've found a bug or have questions please visit our developer forum:
http://groups.google.com/group/google-plus-developers


