== Hangout Apps Sample - Yes No Maybe ==

== What's Included ==
Herein you will find these files which compose the sample

 - ggs/yesnomaybe.js   - The JavaScript file which provides most of the 
                         functionality for this hangouts app
 - ggs/yesnomaybe.xml  - The XML container which describes the app and 
                         provides the initial state
 - static/yesnomaybe/* - Static files including CSS and images

== Getting Help == 
If you somehow got here without finding the documentation, check out
http://developer.google.com/+/hangouts/

If you've found a bug or have questions please visit our developer forum:
http://groups.google.com/group/google-plus-developers


